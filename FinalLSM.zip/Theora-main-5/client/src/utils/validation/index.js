import courseSchema from './course.schema'
import categorySchema from './category.schema'
import lessonSchema from './lesson.schema'
import profileSchema from './profile.schema'

export { courseSchema, categorySchema, lessonSchema, profileSchema }